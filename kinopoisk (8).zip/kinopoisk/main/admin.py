from django.contrib import admin
from .models import Task, Films

admin.site.register(Task)
admin.site.register(Films)