from dataclasses import field
from lib2to3.fixes.fix_input import context
from tkinter.font import names

from django.core.paginator import Paginator
from rest_framework import generics

from .serializers import FilmsSerializer

from django.contrib.admin.templatetags.admin_list import results, search_form
from django.shortcuts import render, redirect
from django.views.generic import ListView
from django.db.models import Q
from main.models import Films
import sqlite3
from .forms import FilmsForm
import os
from django.views.generic.base import View

def index(request):
    contact_list = Films.objects.all()
    paginator = Paginator(contact_list, 48)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    film = Films.objects.all()
    return render(request, 'main/index.html', {'page_obj': page_obj, 'film_list': film})

def about(request):
    return render(request, 'main/about.html')

def search(request):
    if request.method == 'POST':
        query_name = request.POST.get('name', None)
        if query_name:
            stop_words = ['и', 'или', 'в', 'над', 'с', 'без']
            search_terms = []
            for term in query_name.split():
                if term.lower() not in stop_words:
                    if term[-1]!=',':
                        search_terms.append(term)
                    else:
                        search_terms.append(term[:len(term)-1])
            q_objects = Q()
            for term in search_terms:
                q_objects &= Q(teges__icontains=term) | Q(name__icontains=term)
            results = Films.objects.filter(q_objects)
            return render(request, 'main/base.html', {'results': results})
    return render(request, 'main/base.html')

class FilmsAPIView(generics.ListAPIView):
    queryset = Films.objects.all()
    serializer_class = FilmsSerializer



